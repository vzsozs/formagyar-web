/* ============================================================
   script.js – Interakciók + dinamikus fájlkezelő
   Felelős: Ready screen, CRT animáció, fájllista betöltés,
            breadcrumb navigáció, billentyűzet kezelés
   ============================================================ */

// ============================================================
// DOM REFERENCIÁK
// ============================================================
const readyScreen   = document.getElementById('ready-screen');
const mainPanel     = document.getElementById('main-panel');
const btnYes        = document.getElementById('btn-yes');
const btnNo         = document.getElementById('btn-no');
const fileListWrap  = document.getElementById('file-list-wrap');
const breadcrumbBar = document.getElementById('breadcrumb-bar');
const statusCount   = document.getElementById('statusbar-count');
const panelTitle    = document.getElementById('panel-title');

// ============================================================
// ÁLLAPOT – navigáció nyomon követése
// ============================================================
let currentPath   = '';       // Aktuális mappa (relatív a data/ gyökérhöz)
let selectedIndex = 0;        // Billentyűzettel kijelölt sor indexe
let currentItems  = [];       // Az éppen megjelenített elemek tömbje

// ============================================================
// READY SCREEN LOGIKA
// ============================================================

// [Y] gomb: CRT-off animáció, majd főpanel megjelenítése
btnYes.addEventListener('click', () => {
  readyScreen.classList.add('crt-off');

  readyScreen.addEventListener('animationend', () => {
    readyScreen.classList.add('hidden');
    mainPanel.classList.remove('hidden');
    document.body.style.overflow = 'auto';

    // Fájllista betöltése a gyökér mappából
    loadDirectory('');
  }, { once: true });
});

// [N] gomb: hozzáférés megtagadva üzenet
btnNo.addEventListener('click', () => {
  const logLines = document.querySelectorAll('.log-line');
  const lastLog  = logLines[logLines.length - 1];
  if (!lastLog) return;

  lastLog.style.color       = 'var(--orange)';
  lastLog.style.textShadow  = '0 0 8px var(--orange)';
  lastLog.textContent       = '> HOZZÁFÉRÉS MEGTAGADVA. Újrapróbálkozás...';

  setTimeout(() => {
    lastLog.style.color      = '';
    lastLog.style.textShadow = '';
    lastLog.innerHTML        = '&gt; AWAITING USER INPUT';
  }, 1500);
});

// Billentyűzet: Y / N a Ready képernyőn
document.addEventListener('keydown', (e) => {
  if (!readyScreen.classList.contains('hidden')) {
    if (e.key === 'y' || e.key === 'Y') btnYes.click();
    if (e.key === 'n' || e.key === 'N') btnNo.click();
  }
});

// ============================================================
// FÁJLIKON MEGHATÁROZÁSA TÍPUS SZERINT
// ASCII-alapú ikonok, CSS osztállyal színezve
// ============================================================
function getIcon(type) {
  const icons = {
    dir:  { label: '[DIR]', cls: 'icon-dir'  },
    md:   { label: '[MD] ', cls: 'icon-md'   },
    img:  { label: '[IMG]', cls: 'icon-img'  },
    yt:   { label: '[YT] ', cls: 'icon-yt'   },
    txt:  { label: '[TXT]', cls: 'icon-txt'  },
    json: { label: '[JSN]', cls: 'icon-file' },
    js:   { label: '[JS] ', cls: 'icon-file' },
    css:  { label: '[CSS]', cls: 'icon-file' },
    html: { label: '[HTM]', cls: 'icon-file' },
    pdf:  { label: '[PDF]', cls: 'icon-file' },
  };
  return icons[type] || { label: '[---]', cls: 'icon-file' };
}

// ============================================================
// FÁJLLISTA BETÖLTÉSE A SZERVERRŐL
// path: relatív útvonal a data/ gyökérhöz képest
// ============================================================
async function loadDirectory(path) {
  currentPath = path;

  // Betöltés jelzése
  fileListWrap.innerHTML = '<div class="loading-row">&gt; Mappa olvasása</div>';
  statusCount.textContent = 'Betöltés...';

  // Breadcrumb frissítése betöltés közben is
  renderBreadcrumb(path);

  let data;
  try {
    // API hívás: /api/files?path=... (üres string = gyökér)
    const res = await fetch(`/api/files?path=${encodeURIComponent(path || '.')}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    data = await res.json();
  } catch (err) {
    // Hálózati vagy szerverhiba megjelenítése
    fileListWrap.innerHTML = `<div class="error-state">> HIBA: ${err.message}</div>`;
    statusCount.textContent = 'Hiba.';
    return;
  }

  currentItems = data.items;
  selectedIndex = 0;

  renderFileList(data.items);
  renderBreadcrumb(data.path);
  updateStatusBar(data.items);
}

// ============================================================
// FÁJLLISTA RENDERELÉSE A DOM-BA
// ============================================================
function renderFileList(items) {
  // Ha üres a mappa
  if (items.length === 0) {
    fileListWrap.innerHTML = `
      <div class="empty-state">
        <span class="empty-icon">□</span>
        A mappa üres.<br>
        <span style="font-size:7px;color:var(--dim)">
          Hozz létre fájlokat a public/data mappában.
        </span>
      </div>`;
    return;
  }

  // Minden elemhez egy .file-row div épül fel
  fileListWrap.innerHTML = items.map((item, idx) => {
    const icon = getIcon(item.type);
    return `
      <div
        class="file-row${idx === 0 ? ' selected' : ''}"
        data-index="${idx}"
        data-type="${item.type}"
        data-name="${escapeAttr(item.name)}"
        data-isdir="${item.isDir}"
        role="listitem"
        tabindex="0"
        aria-label="${item.name}"
      >
        <span class="col-icon ${icon.cls}">${icon.label}</span>
        <span class="col-name">
          <span class="col-name-text" title="${escapeAttr(item.name)}">${escapeHtml(item.name)}</span>
        </span>
        <span class="col-size">${item.size ?? '—'}</span>
        <span class="col-date">${item.modified ?? ''}</span>
      </div>`;
  }).join('');

  // Kattintás és dupla kattintás kezelése
  fileListWrap.querySelectorAll('.file-row').forEach(row => {
    row.addEventListener('click',    () => selectRow(parseInt(row.dataset.index)));
    row.addEventListener('dblclick', () => openItem(parseInt(row.dataset.index)));
  });
}

// ============================================================
// BREADCRUMB RENDERELÉSE
// A path pl. "projektek/web" → [ROOT] > [projektek] > [web]
// ============================================================
function renderBreadcrumb(path) {
  const parts = path ? path.split('/').filter(Boolean) : [];

  // Gyökér elem mindig ott van
  let html = `<span class="breadcrumb-item${parts.length === 0 ? ' active' : ''}"
    data-path="" title="Gyökér mappa">~/data</span>`;

  // Közbenső mappák
  parts.forEach((part, i) => {
    const subPath = parts.slice(0, i + 1).join('/');
    const isLast  = i === parts.length - 1;
    html += `<span class="breadcrumb-sep">/</span>`;
    html += `<span class="breadcrumb-item${isLast ? ' active' : ''}"
      data-path="${escapeAttr(subPath)}">${escapeHtml(part)}</span>`;
  });

  breadcrumbBar.innerHTML = html;

  // Kattintásra navigálás (nem aktív elemekre)
  breadcrumbBar.querySelectorAll('.breadcrumb-item:not(.active)').forEach(el => {
    el.addEventListener('click', () => loadDirectory(el.dataset.path));
  });
}

// ============================================================
// ÁLLAPOTSOR FRISSÍTÉSE
// ============================================================
function updateStatusBar(items) {
  const dirs  = items.filter(i => i.isDir).length;
  const files = items.filter(i => !i.isDir).length;
  statusCount.textContent = `${dirs} mappa, ${files} fájl`;
}

// ============================================================
// SOR KIJELÖLÉSE (billentyűzet / egér)
// ============================================================
function selectRow(index) {
  // Előző kijelölés törlése
  const prev = fileListWrap.querySelector('.file-row.selected');
  if (prev) prev.classList.remove('selected');

  selectedIndex = Math.max(0, Math.min(index, currentItems.length - 1));

  const next = fileListWrap.querySelector(`[data-index="${selectedIndex}"]`);
  if (next) {
    next.classList.add('selected');
    // Görgetés: sor látható legyen
    next.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
}

// ============================================================
// ELEM MEGNYITÁSA (mappa: navigálás; fájl: egyelőre log)
// ============================================================
function openItem(index) {
  const item = currentItems[index];
  if (!item) return;

  if (item.isDir) {
    // Mappa megnyitása: útvonal összerakása és betöltés
    const newPath = currentPath ? `${currentPath}/${item.name}` : item.name;
    loadDirectory(newPath);
  } else if (item.type === 'md') {
    // Markdown fájl: betöltés + megjelenítés modal-ban
    openMarkdown(item);
  } else if (item.type === 'yt') {
    // YouTube fájl: URL kiolvasás + embed lejátszó modal-ban
    openYouTube(item);
  } else {
    // Egyéb fájltípus: státuszsorban jelezzük (later task)
    statusCount.textContent = `> ${item.name} – nem támogatott nézet`;
    setTimeout(() => updateStatusBar(currentItems), 2000);
  }
}

// ============================================================
// MODAL MEGNYITÁSA / BEZÁRÁSA
// ============================================================

const viewerOverlay = document.getElementById('viewer-overlay');
const viewerBox     = document.getElementById('viewer-box');
const viewerTitle   = document.getElementById('viewer-title');
const viewerContent = document.getElementById('viewer-content');
const viewerClose   = document.getElementById('viewer-close');

// Modal megnyitása – cím és tartalom HTML átadásával
function openViewer(title, contentHtml, extraClass = '') {
  viewerTitle.textContent = title;
  viewerContent.innerHTML = contentHtml;

  // Extra CSS osztály (pl. 'viewer-yt' a YT lejátszóhoz)
  viewerBox.className = 'viewer-box' + (extraClass ? ` ${extraClass}` : '');

  viewerOverlay.classList.remove('hidden');

  // Fókusz a bezárás gombra (akadálymentesség)
  viewerClose.focus();
}

// Modal bezárása
function closeViewer() {
  viewerOverlay.classList.add('hidden');
  viewerContent.innerHTML = ''; // YT iframe leállítása is így történik
}

// Bezárás gomb kattintásra
viewerClose.addEventListener('click', closeViewer);

// Overlay háttérre kattintva is bezár
viewerOverlay.addEventListener('click', (e) => {
  if (e.target === viewerOverlay) closeViewer();
});

// ESC billentyűre bezár
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !viewerOverlay.classList.contains('hidden')) {
    closeViewer();
  }
});

// ============================================================
// MARKDOWN MEGJELENÍTŐ
// Fetch-szel lekéri a fájl tartalmát, marked.js-sel rendereli
// ============================================================
async function openMarkdown(item) {
  // Betöltés közben: spinner szöveg a modal-ban
  openViewer(item.name, '<div class="viewer-loading">&gt; Markdown betöltése<span class="loading-dots"></span></div>');

  const filePath = currentPath ? `${currentPath}/${item.name}` : item.name;

  let raw;
  try {
    // /api/read végponton keresztül kérjük le a nyers szöveget
    const res = await fetch(`/api/read?path=${encodeURIComponent(filePath)}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    raw = await res.text();
  } catch (err) {
    openViewer(item.name, `<div class="viewer-error">&gt; HIBA: ${escapeHtml(err.message)}</div>`);
    return;
  }

  // marked.js: nyers Markdown → HTML
  // A 'breaks: true' sorvégeket <br>-ré alakítja (terminál-barát)
  const html = marked.parse(raw, { breaks: true, gfm: true });

  // Csomagoló div a stílusozáshoz
  openViewer(item.name, `<div class="md-body">${html}</div>`);
}

// ============================================================
// YOUTUBE LEJÁTSZÓ
// A .yt fájlból kinyeri az URL-t, majd iframe embed-et hoz létre
// ============================================================
async function openYouTube(item) {
  openViewer(item.name, '<div class="viewer-loading">&gt; Videó betöltése<span class="loading-dots"></span></div>', 'viewer-yt');

  const filePath = currentPath ? `${currentPath}/${item.name}` : item.name;

  let raw;
  try {
    const res = await fetch(`/api/read?path=${encodeURIComponent(filePath)}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    raw = await res.text();
  } catch (err) {
    openViewer(item.name, `<div class="viewer-error">&gt; HIBA: ${escapeHtml(err.message)}</div>`);
    return;
  }

  // Az első nem-üres sort tekintjük YouTube URL-nek
  const url = raw.trim().split('\n')[0].trim();

  // YouTube video ID kinyerése az URL-ből
  // Támogatja: youtube.com/watch?v=..., youtu.be/..., youtube.com/shorts/...
  const videoId = extractYouTubeId(url);

  if (!videoId) {
    openViewer(item.name,
      `<div class="viewer-error">&gt; Érvénytelen YouTube URL:<br><span style="font-size:8px;color:var(--dim)">${escapeHtml(url)}</span></div>`,
      'viewer-yt'
    );
    return;
  }

  // Embed iframe: youtube-nocookie.com (adatvédelem-barát YouTube embed)
  const embedUrl = `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`;

  const html = `
    <div class="yt-wrap">
      <div class="yt-scanline" aria-hidden="true"></div>
      <iframe
        class="yt-iframe"
        src="${embedUrl}"
        title="YouTube lejátszó"
        frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
      ></iframe>
    </div>
    <div class="yt-meta">
      <span class="yt-label">[YT]</span>
      <span class="yt-url">${escapeHtml(url)}</span>
    </div>`;

  openViewer(item.name, html, 'viewer-yt');
}

// YouTube video ID kinyerése különböző URL formátumokból
function extractYouTubeId(url) {
  const patterns = [
    /[?&]v=([a-zA-Z0-9_-]{11})/,          // youtube.com/watch?v=...
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,      // youtu.be/...
    /\/shorts\/([a-zA-Z0-9_-]{11})/,       // youtube.com/shorts/...
    /\/embed\/([a-zA-Z0-9_-]{11})/,        // youtube.com/embed/...
  ];
  for (const re of patterns) {
    const m = url.match(re);
    if (m) return m[1];
  }
  return null;
}

// Visszalépés szülő mappába
function goUp() {
  if (!currentPath) return; // Már a gyökérben vagyunk
  const parts    = currentPath.split('/').filter(Boolean);
  const parentPath = parts.slice(0, -1).join('/');
  loadDirectory(parentPath);
}

// ============================================================
// BILLENTYŰZET NAVIGÁCIÓ A FÁJLLISTÁBAN
// ============================================================
document.addEventListener('keydown', (e) => {
  // Csak a főpanel aktív esetén
  if (mainPanel.classList.contains('hidden')) return;

  switch (e.key) {
    case 'ArrowDown':
      e.preventDefault();
      selectRow(selectedIndex + 1);
      break;

    case 'ArrowUp':
      e.preventDefault();
      selectRow(selectedIndex - 1);
      break;

    case 'Enter':
      e.preventDefault();
      openItem(selectedIndex);
      break;

    case 'Backspace':
      // Vissza a szülő mappába
      e.preventDefault();
      goUp();
      break;

    case 'Home':
      e.preventDefault();
      selectRow(0);
      break;

    case 'End':
      e.preventDefault();
      selectRow(currentItems.length - 1);
      break;
  }
});

// ============================================================
// SEGÉDFÜGGVÉNYEK (XSS-védelem)
// ============================================================

// HTML speciális karakterek escapelése (megjelenítéshez)
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// HTML attribútum érték escapelése
function escapeAttr(str) {
  return String(str).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
